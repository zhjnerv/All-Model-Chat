import React, { useState, useCallback, useRef } from 'react';
import { ChatMessage, MessageListProps, UploadedFile, ThemeColors } from '../types';
import { Message } from './message/Message';
import { X, Bot, Zap, ArrowUp, ArrowDown } from 'lucide-react';
import { translations, getResponsiveValue } from '../utils/appUtils';
import { HtmlPreviewModal } from './HtmlPreviewModal';
import { ImageZoomModal } from './shared/ImageZoomModal';

const SUGGESTIONS_KEYS = [
  { titleKey: 'suggestion_summarize_title', descKey: 'suggestion_summarize_desc' },
  { titleKey: 'suggestion_explain_title', descKey: 'suggestion_explain_desc' },
  { titleKey: 'suggestion_translate_title', descKey: 'suggestion_translate_desc' },
  { titleKey: 'suggestion_ocr_title', descKey: 'suggestion_ocr_desc' },
];

export const MessageList: React.FC<MessageListProps> = ({ 
    messages, messagesEndRef, scrollContainerRef, onScrollContainerScroll, 
    onEditMessage, onDeleteMessage, onRetryMessage, showThoughts, themeColors, baseFontSize,
    expandCodeBlocksByDefault, onSuggestionClick, onTextToSpeech, ttsMessageId, t, language, themeId,
    showScrollToBottom, onScrollToBottom
}) => {
  const [zoomedFile, setZoomedFile] = useState<UploadedFile | null>(null);
  
  const [isHtmlPreviewModalOpen, setIsHtmlPreviewModalOpen] = useState(false);
  const [htmlToPreview, setHtmlToPreview] = useState<string | null>(null);
  const [initialTrueFullscreenRequest, setInitialTrueFullscreenRequest] = useState(false);
  
  const handleImageClick = useCallback((file: UploadedFile) => {
    setZoomedFile(file);
  }, []);

  const closeImageZoomModal = useCallback(() => {
    setZoomedFile(null);
  }, []);

  const handleOpenHtmlPreview = useCallback((
      htmlContent: string, 
      options?: { initialTrueFullscreen?: boolean }
    ) => {
    setHtmlToPreview(htmlContent);
    setInitialTrueFullscreenRequest(options?.initialTrueFullscreen ?? false);
    setIsHtmlPreviewModalOpen(true);
  }, []);

  const handleCloseHtmlPreview = useCallback(() => {
    setIsHtmlPreviewModalOpen(false);
    setHtmlToPreview(null);
    setInitialTrueFullscreenRequest(false);
  }, []);

  return (
    <>
    <div 
      ref={scrollContainerRef}
      onScroll={onScrollContainerScroll}
      className="flex-grow overflow-y-auto p-3 sm:p-4 md:p-6 pb-0 bg-[var(--theme-bg-secondary)] custom-scrollbar"
      aria-live="polite" 
    >
      {messages.length === 0 ? (
        <div className="flex flex-col items-center justify-center min-h-full w-full max-w-7xl mx-auto px-4 pb-24">
          <div className="w-full">
            <h1 className="text-4xl sm:text-5xl font-bold text-center text-[var(--theme-text-primary)] mb-8 sm:mb-12 welcome-message-animate">
              {t('welcome_greeting')}
            </h1>
            <div className="text-left mb-2 sm:mb-3 flex items-center gap-2 text-sm font-medium text-[var(--theme-text-secondary)]">
              <Zap size={16} className="text-[var(--theme-text-link)]" />
              <span>{t('welcome_suggestion_title')}</span>
            </div>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
              {SUGGESTIONS_KEYS.map((s, i) => (
                <button
                  key={i}
                  onClick={() => onSuggestionClick && onSuggestionClick(t(s.descKey as any))}
                  className="bg-[var(--theme-bg-tertiary)] border border-transparent hover:border-[var(--theme-border-secondary)] rounded-2xl p-3 sm:p-4 text-left h-40 sm:h-44 flex flex-col group justify-between hover:bg-[var(--theme-bg-input)] transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-[var(--theme-border-focus)]"
                  style={{ animation: `fadeInUp 0.5s ${0.2 + i * 0.1}s ease-out both` }}
                >
                  <div>
                    <h3 className="font-semibold text-base text-[var(--theme-text-primary)]">{t(s.titleKey as any)}</h3>
                    <p className="text-sm text-[var(--theme-text-secondary)] mt-1">{t(s.descKey as any)}</p>
                  </div>
                  <div className="flex justify-between items-center mt-auto text-[var(--theme-text-tertiary)] opacity-70 group-hover:opacity-100 transition-opacity">
                    <span className="text-sm">{t('suggestion_prompt_label')}</span>
                    <ArrowUp size={20} />
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>
      ) : (
        <div className="w-full max-w-7xl mx-auto">
          {messages.map((msg: ChatMessage, index: number) => (
            <Message
              key={msg.id}
              message={msg}
              prevMessage={index > 0 ? messages[index - 1] : undefined}
              messageIndex={index}
              onEditMessage={onEditMessage}
              onDeleteMessage={onDeleteMessage}
              onRetryMessage={onRetryMessage}
              onImageClick={handleImageClick}
              onOpenHtmlPreview={handleOpenHtmlPreview}
              showThoughts={showThoughts}
              themeColors={themeColors}
              themeId={themeId}
              baseFontSize={baseFontSize}
              expandCodeBlocksByDefault={expandCodeBlocksByDefault}
              onTextToSpeech={onTextToSpeech}
              ttsMessageId={ttsMessageId}
              t={t}
            />
          ))}
        </div>
      )}
       {showScrollToBottom && (
          <button
            onClick={onScrollToBottom}
            className="sticky z-10 bottom-4 right-4 ml-auto block p-2 bg-[var(--theme-bg-tertiary)] text-[var(--theme-text-primary)] rounded-full shadow-lg hover:bg-[var(--theme-bg-input)] hover:text-[var(--theme-text-primary)] transition-all duration-200 ease-in-out transform hover:scale-105 focus:outline-none focus:ring-2 focus:ring-[var(--theme-border-focus)]"
            style={{ animation: 'fadeInUp 0.3s ease-out both' }}
            aria-label="Scroll to bottom"
            title="Scroll to bottom"
          >
            <ArrowDown size={20} />
          </button>
        )}
      <div ref={messagesEndRef} />
    </div>
    <ImageZoomModal 
        file={zoomedFile} 
        onClose={closeImageZoomModal}
        themeColors={themeColors}
        t={t}
    />
    {isHtmlPreviewModalOpen && htmlToPreview !== null && (
      <HtmlPreviewModal
        isOpen={isHtmlPreviewModalOpen}
        onClose={handleCloseHtmlPreview}
        htmlContent={htmlToPreview}
        themeColors={themeColors}
        initialTrueFullscreenRequest={initialTrueFullscreenRequest}
      />
    )}
    </>
  );
};